import React, { Component } from 'react';
import {
    View,
    ActivityIndicator
} from 'react-native';

import Styles from '../styles';
const { CommonStyles, StyleConfig }  = Styles;

class Spinner extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <View style={[CommonStyles.m_a_4, this.props.style]}>
                <ActivityIndicator
                    animating={true}
                    size={'large'}
                    color={StyleConfig.color_primary}
                    {...this.props} />
            </View>
        )
    }
}

export default Spinner;