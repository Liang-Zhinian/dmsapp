import { NativeModules } from 'react-native';

module.exports = NativeModules.FileViewer;