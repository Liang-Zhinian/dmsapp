
import {
    requireNativeComponent,
} from 'react-native';

module.exports = requireNativeComponent('RNQuickLook', null);