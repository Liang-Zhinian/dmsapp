import { NativeModules } from 'react-native';

// module.exports = NativeModules.SimpleIntentModule;
module.exports = NativeModules.RicohScanner;
// module.exports = NativeModules.RCTRicohScanner;