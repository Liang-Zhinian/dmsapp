
const colors = {
    primary: '#0D83DD',
    textOnPrimary: 'white',
    borderOnPrimary: '#0067B7',
};

export default colors;