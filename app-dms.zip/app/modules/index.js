import { default as Documents } from './documents';
// import { default as Home } from './home';

export {
    Documents,
    // Home,
};