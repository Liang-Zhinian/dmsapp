import Styles from '../../../styles';

export const colors = Styles.colors;
export const CommonStyles = Styles.CommonStyles;
export const ComponentStyles = Styles.ComponentStyles;
export const StyleConfig = Styles.StyleConfig;